# EvolSphere Basic
Open index.html.