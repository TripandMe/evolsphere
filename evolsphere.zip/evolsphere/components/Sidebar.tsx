"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";

const NAV = [
  { href: "/", label: "Vue d'ensemble", icon: "◈" },
  { href: "/opex", label: "OPEX", icon: "⬡" },
  { href: "/traversee", label: "Traversée", icon: "⛵" },
  { href: "/agenda", label: "Agenda", icon: "◷" },
  { href: "/documents", label: "Documents", icon: "⬒" },
];

interface SidebarProps {
  user: { name?: string | null; role?: string; avatar?: string };
}

export default function Sidebar({ user }: SidebarProps) {
  const path = usePathname();

  return (
    <aside style={{
      width: "220px",
      minHeight: "100vh",
      background: "var(--sea)",
      borderRight: "1px solid var(--rule2)",
      display: "flex",
      flexDirection: "column",
      position: "fixed",
      top: 0,
      left: 0,
      zIndex: 50,
    }}>
      {/* Logo */}
      <div style={{ padding: "1.8rem 1.6rem 1.2rem", borderBottom: "1px solid var(--rule2)" }}>
        <div style={{
          fontFamily: "Georgia, serif",
          fontSize: "1rem",
          fontWeight: 200,
          color: "var(--salt)",
          letterSpacing: "0.04em",
        }}>
          Evol<span style={{ color: "var(--wake)" }}>Sphere</span>
        </div>
        <div style={{
          fontFamily: "monospace",
          fontSize: "0.45rem",
          letterSpacing: "0.16em",
          textTransform: "uppercase",
          color: "var(--mist)",
          marginTop: "0.3rem",
        }}>Cercle Privé</div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: "1.2rem 0" }}>
        {NAV.map(item => {
          const active = path === item.href;
          return (
            <Link key={item.href} href={item.href} style={{
              display: "flex",
              alignItems: "center",
              gap: "0.8rem",
              padding: "0.75rem 1.6rem",
              textDecoration: "none",
              color: active ? "var(--salt)" : "var(--foam)",
              background: active ? "rgba(78,155,179,0.08)" : "transparent",
              borderLeft: active ? "2px solid var(--wake)" : "2px solid transparent",
              transition: "all 0.18s",
              fontSize: "0.82rem",
            }}>
              <span style={{ fontSize: "0.8rem", color: active ? "var(--wake)" : "var(--mist)" }}>
                {item.icon}
              </span>
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* User */}
      <div style={{
        padding: "1.2rem 1.6rem",
        borderTop: "1px solid var(--rule2)",
        display: "flex",
        flexDirection: "column",
        gap: "0.8rem",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.8rem" }}>
          <div style={{
            width: "30px", height: "30px", borderRadius: "50%",
            background: "rgba(78,155,179,0.15)",
            border: "1px solid var(--rule)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontFamily: "monospace", fontSize: "0.55rem", color: "var(--wake)",
          }}>
            {user.avatar || "?"}
          </div>
          <div>
            <div style={{ fontSize: "0.78rem", color: "var(--salt)", fontWeight: 400 }}>
              {user.name?.split(" ")[0]}
            </div>
            <div style={{
              fontFamily: "monospace", fontSize: "0.46rem",
              letterSpacing: "0.1em", color: "var(--mist)", textTransform: "uppercase",
            }}>
              {(user as any).role || "Membre"}
            </div>
          </div>
        </div>
        <button
          onClick={() => signOut({ callbackUrl: "/login" })}
          style={{
            background: "transparent",
            border: "1px solid var(--rule2)",
            color: "var(--mist)",
            fontFamily: "monospace",
            fontSize: "0.48rem",
            letterSpacing: "0.14em",
            textTransform: "uppercase",
            padding: "0.4rem 0.8rem",
            cursor: "pointer",
            transition: "all 0.2s",
            width: "100%",
          }}
        >
          Déconnexion
        </button>
      </div>
    </aside>
  );
}
