import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EvolSphere · Cercle Privé",
  description: "Espace membres EvolSphere — pilotage OPEX & art de naviguer",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
