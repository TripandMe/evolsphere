"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });
    setLoading(false);
    if (res?.error) {
      setError("Identifiants incorrects.");
    } else {
      router.push("/");
    }
  }

  return (
    <div style={{
      minHeight: "100vh",
      background: "var(--deep)",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      padding: "2rem",
      position: "relative",
      overflow: "hidden",
    }}>
      {/* Background gradient */}
      <div style={{
        position: "absolute", inset: 0,
        background: "radial-gradient(ellipse at 60% 40%, rgba(78,155,179,0.06) 0%, transparent 60%)",
        pointerEvents: "none",
      }} />

      {/* Logo */}
      <div style={{
        fontFamily: "Georgia, serif",
        fontSize: "1.5rem",
        fontWeight: 200,
        color: "var(--salt)",
        marginBottom: "3rem",
        letterSpacing: "0.04em",
      }}>
        Evol<span style={{ color: "var(--wake)" }}>Sphere</span>
      </div>

      {/* Card */}
      <div style={{
        width: "100%",
        maxWidth: "360px",
        background: "var(--sea)",
        border: "1px solid var(--rule)",
        padding: "2.8rem 2.4rem",
        position: "relative",
      }}>
        <div style={{
          position: "absolute", top: 0, left: 0, right: 0, height: "1px",
          background: "linear-gradient(to right, transparent, var(--wake), transparent)",
          opacity: 0.4,
        }} />

        <p style={{
          fontFamily: "monospace",
          fontSize: "0.52rem",
          letterSpacing: "0.22em",
          textTransform: "uppercase",
          color: "var(--wake)",
          marginBottom: "1.8rem",
        }}>
          Accès membres
        </p>

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "1.2rem" }}>
          <div>
            <label style={{
              display: "block",
              fontFamily: "monospace",
              fontSize: "0.5rem",
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: "var(--foam)",
              marginBottom: "0.5rem",
            }}>Email</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              style={{
                width: "100%",
                background: "transparent",
                border: "none",
                borderBottom: "1px solid var(--rule)",
                color: "var(--salt)",
                fontFamily: "inherit",
                fontSize: "0.88rem",
                padding: "0.6rem 0",
                outline: "none",
              }}
              placeholder="votre@organisation.fr"
            />
          </div>

          <div>
            <label style={{
              display: "block",
              fontFamily: "monospace",
              fontSize: "0.5rem",
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: "var(--foam)",
              marginBottom: "0.5rem",
            }}>Mot de passe</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              style={{
                width: "100%",
                background: "transparent",
                border: "none",
                borderBottom: "1px solid var(--rule)",
                color: "var(--salt)",
                fontFamily: "inherit",
                fontSize: "0.88rem",
                padding: "0.6rem 0",
                outline: "none",
              }}
              placeholder="••••••••"
            />
          </div>

          {error && (
            <p style={{ fontSize: "0.75rem", color: "#e74c3c" }}>{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              marginTop: "0.8rem",
              padding: "0.9rem 2rem",
              background: loading ? "var(--rule)" : "transparent",
              border: "1px solid rgba(78,155,179,0.4)",
              color: "var(--wake)",
              fontFamily: "monospace",
              fontSize: "0.56rem",
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              cursor: loading ? "not-allowed" : "pointer",
              transition: "all 0.25s",
              width: "100%",
            }}
          >
            {loading ? "Connexion…" : "Accéder à mon espace"}
          </button>
        </form>

        <p style={{
          marginTop: "2rem",
          fontFamily: "monospace",
          fontSize: "0.48rem",
          letterSpacing: "0.1em",
          color: "var(--mist)",
          textAlign: "center",
          lineHeight: 1.8,
        }}>
          Accès réservé aux membres EvolSphere<br />
          Demo: membre1@evolsphere.io / evol2025
        </p>
      </div>
    </div>
  );
}
