import { auth } from "@/auth";
import { OPEX_DATA } from "@/data/opex";
import { AGENDA } from "@/data/agenda";
import Link from "next/link";

function fmt(n: number) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(n);
}

export default async function DashboardPage() {
  const session = await auth();
  const active = OPEX_DATA.filter(o => o.status === "on" || o.status === "watch");
  const atRisk = OPEX_DATA.filter(o => o.status === "watch");
  const totalBudget = OPEX_DATA.reduce((s, o) => s + o.budgetEngaged, 0);
  const nextEvent = AGENDA[0];

  return (
    <div style={{ padding: "3rem 3rem 4rem" }}>
      {/* Header */}
      <div style={{ marginBottom: "3rem" }}>
        <p style={{
          fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.22em",
          textTransform: "uppercase", color: "var(--wake)", marginBottom: "0.8rem",
        }}>
          Bonjour, {session?.user?.name?.split(" ")[0]}
        </p>
        <h1 style={{
          fontFamily: "Georgia, serif", fontWeight: 200,
          fontSize: "clamp(1.8rem, 3vw, 2.8rem)", color: "var(--salt)",
          letterSpacing: "-0.01em", lineHeight: 1.1,
        }}>
          Vue d'ensemble
        </h1>
      </div>

      {/* KPIs */}
      <div style={{
        display: "grid", gridTemplateColumns: "repeat(4, 1fr)",
        gap: "1px", background: "var(--rule2)",
        border: "1px solid var(--rule2)", marginBottom: "3rem",
      }}>
        {[
          { k: "OPEX actifs", v: `${active.length}`, sub: "opérations en cours", color: "var(--green)" },
          { k: "Points vigilance", v: `${atRisk.length}`, sub: "jalons à surveiller", color: "var(--amber)" },
          { k: "Budget engagé", v: fmt(totalBudget), sub: "sur 4 opérations", color: "var(--wake2)" },
          { k: "Prochain événement", v: `${nextEvent.day} ${nextEvent.month}`, sub: nextEvent.title.slice(0, 30) + "…", color: "var(--salt)" },
        ].map((kpi, i) => (
          <div key={i} style={{
            background: "var(--sea)", padding: "1.6rem 1.8rem",
            display: "flex", flexDirection: "column", gap: "0.3rem",
          }}>
            <span style={{
              fontFamily: "monospace", fontSize: "0.48rem",
              letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--wake)", opacity: 0.7,
            }}>{kpi.k}</span>
            <span style={{
              fontFamily: "Georgia, serif", fontWeight: 200,
              fontSize: "1.5rem", color: kpi.color, lineHeight: 1,
            }}>{kpi.v}</span>
            <span style={{ fontSize: "0.72rem", color: "var(--foam)" }}>{kpi.sub}</span>
          </div>
        ))}
      </div>

      {/* OPEX snapshot */}
      <div style={{ marginBottom: "3rem" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "1.5rem" }}>
          <h2 style={{
            fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.3rem", color: "var(--salt)",
          }}>OPEX en cours</h2>
          <Link href="/opex" style={{
            fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.14em",
            textTransform: "uppercase", color: "var(--wake)", textDecoration: "none",
          }}>Voir tout →</Link>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: "1px", background: "var(--rule2)" }}>
          {OPEX_DATA.map(op => {
            const statusColor = op.status === "on" ? "var(--green)" : op.status === "watch" ? "var(--amber)" : "var(--wake2)";
            const statusLabel = { on: "En cours", watch: "Vigilance", plan: "Planifié", done: "Terminé" }[op.status];
            return (
              <Link key={op.id} href={`/opex#${op.id}`} style={{
                background: "var(--sea)", padding: "1.2rem 1.8rem",
                display: "grid", gridTemplateColumns: "1fr 120px 80px 100px",
                alignItems: "center", gap: "2rem", textDecoration: "none",
                transition: "background 0.2s",
              }}>
                <span style={{ fontSize: "0.87rem", color: "var(--salt)", fontWeight: 300 }}>{op.name}</span>
                <div style={{ height: "2px", background: "var(--rule2)", borderRadius: "1px", overflow: "hidden" }}>
                  <div style={{
                    height: "100%", width: `${op.progress}%`, borderRadius: "1px",
                    background: op.status === "watch"
                      ? "linear-gradient(to right, var(--amber), #E8C06A)"
                      : "linear-gradient(to right, var(--wake), var(--wake2))",
                  }} />
                </div>
                <span style={{
                  fontFamily: "monospace", fontSize: "0.52rem",
                  letterSpacing: "0.1em", color: "var(--foam)",
                }}>{op.progress}%</span>
                <span style={{
                  fontFamily: "monospace", fontSize: "0.5rem",
                  letterSpacing: "0.1em", textTransform: "uppercase",
                  color: statusColor, textAlign: "right",
                }}>{statusLabel}</span>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Quick agenda */}
      <div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "1.5rem" }}>
          <h2 style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.3rem", color: "var(--salt)" }}>
            Agenda — prochains rendez-vous
          </h2>
          <Link href="/agenda" style={{
            fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.14em",
            textTransform: "uppercase", color: "var(--wake)", textDecoration: "none",
          }}>Voir tout →</Link>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: "1px", background: "var(--rule2)" }}>
          {AGENDA.slice(0, 3).map(ev => (
            <div key={ev.id} style={{
              background: "var(--sea)", padding: "1.1rem 1.8rem",
              display: "grid", gridTemplateColumns: "80px 1fr auto",
              alignItems: "center", gap: "2rem",
            }}>
              <div>
                <div style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.2rem", color: "var(--salt)", lineHeight: 1 }}>{ev.day}</div>
                <div style={{ fontFamily: "monospace", fontSize: "0.48rem", letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--wake)", marginTop: "0.2rem" }}>{ev.month}</div>
              </div>
              <div>
                <div style={{ fontSize: "0.84rem", color: "var(--salt)" }}>{ev.title}</div>
                <div style={{ fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.08em", color: "var(--foam)", marginTop: "0.2rem" }}>{ev.where}</div>
              </div>
              <span style={{
                fontFamily: "monospace", fontSize: "0.48rem", letterSpacing: "0.1em",
                textTransform: "uppercase", padding: "0.25rem 0.7rem",
                border: "1px solid var(--rule)", color: "var(--foam)",
              }}>{ev.tag}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
