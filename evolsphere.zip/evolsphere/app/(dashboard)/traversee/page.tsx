export default function TraverseePage() {
  const islands = [
    { icon: "🏝", name: "Palma de Mallorca", tag: "Départ · 18 juillet", desc: "Marina Portitxol, 08h00. Briefing sécurité, répartition des quarts." },
    { icon: "⚓", name: "Cala d'Or", tag: "Escale · J+1", desc: "Mouillage calme, calanques turquoise. Dîner à bord au coucher du soleil." },
    { icon: "🌊", name: "Ibiza — Es Vedrà", tag: "Passage · J+2", desc: "Navigation de nuit en option. Mouillage face au rocher sacré." },
    { icon: "🏖", name: "Formentera", tag: "Terminus · J+4–5", desc: "Platja de Ses Illetes. Eaux de lagon. Retour maritime ou vol direct." },
  ];

  const meteo = [
    { day: "Lun 18/07", icon: "⛵", wind: "14 nœuds", bft: "Bft 4 · NE" },
    { day: "Mar 19/07", icon: "🌤", wind: "8 nœuds", bft: "Bft 3 · E" },
    { day: "Mer 20/07", icon: "☀️", wind: "11 nœuds", bft: "Bft 3 · SE" },
    { day: "Jeu 21/07", icon: "🌤", wind: "16 nœuds", bft: "Bft 4 · N" },
    { day: "Ven 22/07", icon: "⛵", wind: "13 nœuds", bft: "Bft 4 · NE" },
  ];

  return (
    <div style={{ padding: "3rem 3rem 5rem" }}>
      <p style={{ fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--wake)", marginBottom: "0.8rem" }}>
        La mer · Les Baléares
      </p>
      <h1 style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "clamp(1.8rem, 3vw, 2.8rem)", color: "var(--salt)", marginBottom: "0.5rem" }}>
        Traversée d'été
      </h1>
      <p style={{ fontFamily: "monospace", fontSize: "0.54rem", letterSpacing: "0.1em", color: "var(--wake)", marginBottom: "3rem" }}>
        39°33'N 002°38'E · Palma de Mallorca · Juillet 2025
      </p>

      {/* Intro */}
      <div style={{
        borderLeft: "1px solid var(--rule)", paddingLeft: "2rem",
        maxWidth: "600px", marginBottom: "3rem",
      }}>
        <p style={{ fontSize: "0.87rem", color: "var(--foam)", lineHeight: 2, marginBottom: "1rem" }}>
          Quelques membres qui savent <strong style={{ color: "var(--salt)", fontWeight: 400 }}>tenir un cap</strong> — dans leurs opérations comme à la barre.
        </p>
        <p style={{ fontSize: "0.87rem", color: "var(--foam)", lineHeight: 2, marginBottom: "1rem" }}>
          Cet été, EvolSphere affrète un voilier de 50 pieds pour une traversée Palma–Ibiza–Formentera. Cinq jours. <strong style={{ color: "var(--salt)", fontWeight: 400 }}>Six membres maximum.</strong> Sans programme fixé au-delà du vent.
        </p>
        <p style={{ fontSize: "0.87rem", color: "var(--foam)", lineHeight: 2 }}>
          Les mouillages se décident au lever. Les dîners se trouvent à quai. Le reste vient de lui-même.
        </p>
      </div>

      {/* Places */}
      <div style={{
        background: "var(--sea)", border: "1px solid rgba(78,155,179,0.25)",
        padding: "1.4rem 2rem", marginBottom: "3rem", display: "flex",
        justifyContent: "space-between", alignItems: "center", gap: "2rem",
        position: "relative", overflow: "hidden",
      }}>
        <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "1px", background: "linear-gradient(to right, transparent, var(--wake), transparent)", opacity: 0.4 }} />
        <div>
          <div style={{ fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--wake)", marginBottom: "0.4rem" }}>Disponibilité</div>
          <div style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.4rem", color: "var(--salt)" }}>3 places disponibles</div>
          <div style={{ fontSize: "0.75rem", color: "var(--foam)", marginTop: "0.2rem" }}>Sur invitation · 6 membres maximum</div>
        </div>
        <a href="mailto:contact@evolsphere.io?subject=Traversée Baléares — Juillet 2025" style={{
          display: "inline-block",
          padding: "0.8rem 2rem",
          background: "transparent",
          border: "1px solid rgba(78,155,179,0.4)",
          color: "var(--wake)",
          fontFamily: "monospace",
          fontSize: "0.54rem",
          letterSpacing: "0.16em",
          textTransform: "uppercase",
          textDecoration: "none",
          whiteSpace: "nowrap",
        }}>
          Exprimer mon intérêt
        </a>
      </div>

      {/* Islands grid */}
      <h2 style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.3rem", color: "var(--salt)", marginBottom: "1.5rem" }}>Itinéraire</h2>
      <div style={{
        display: "grid", gridTemplateColumns: "1fr 1fr",
        gap: "1px", background: "var(--rule2)",
        border: "1px solid var(--rule2)", marginBottom: "2.5rem",
      }}>
        {islands.map((isl, i) => (
          <div key={i} style={{
            background: "var(--sea)", padding: "1.8rem 2rem",
          }}>
            <div style={{ fontSize: "1.6rem", marginBottom: "0.7rem" }}>{isl.icon}</div>
            <div style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1rem", color: "var(--salt)", marginBottom: "0.3rem" }}>{isl.name}</div>
            <div style={{ fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--wake)", marginBottom: "0.5rem" }}>{isl.tag}</div>
            <div style={{ fontSize: "0.78rem", color: "var(--foam)", lineHeight: 1.7 }}>{isl.desc}</div>
          </div>
        ))}
      </div>

      {/* Meteo */}
      <h2 style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.3rem", color: "var(--salt)", marginBottom: "1.5rem" }}>Météo prévisionnelle</h2>
      <div style={{
        display: "grid", gridTemplateColumns: "repeat(5, 1fr)",
        gap: "1px", background: "var(--rule2)", border: "1px solid var(--rule2)",
      }}>
        {meteo.map((m, i) => (
          <div key={i} style={{
            background: "var(--sea)", padding: "1.4rem 1rem",
            textAlign: "center",
          }}>
            <div style={{ fontFamily: "monospace", fontSize: "0.48rem", letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--wake)", marginBottom: "0.5rem" }}>{m.day}</div>
            <div style={{ fontSize: "1.4rem", marginBottom: "0.4rem" }}>{m.icon}</div>
            <div style={{ fontFamily: "monospace", fontSize: "0.62rem", color: "var(--salt)", letterSpacing: "0.06em" }}>{m.wind}</div>
            <div style={{ fontSize: "0.65rem", color: "var(--foam)", marginTop: "0.2rem" }}>{m.bft}</div>
          </div>
        ))}
      </div>

      <p style={{ fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.1em", color: "var(--mist)", textAlign: "center", marginTop: "1rem" }}>
        Météo indicative · Mise à jour J−7
      </p>
    </div>
  );
}
