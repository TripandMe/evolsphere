import { OPEX_DATA, STATUS_LABELS } from "@/data/opex";

function fmt(n: number) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(n);
}

export default function OpexPage() {
  const total = OPEX_DATA.reduce((s, o) => s + o.budgetEngaged, 0);
  const totalAlloc = OPEX_DATA.reduce((s, o) => s + o.budgetTotal, 0);

  return (
    <div style={{ padding: "3rem 3rem 5rem" }}>
      <p style={{ fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--wake)", marginBottom: "0.8rem" }}>
        Opérations
      </p>
      <h1 style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "clamp(1.8rem, 3vw, 2.8rem)", color: "var(--salt)", marginBottom: "3rem" }}>
        Vos OPEX
      </h1>

      {/* Summary row */}
      <div style={{
        display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1px",
        background: "var(--rule2)", border: "1px solid var(--rule2)", marginBottom: "3rem",
      }}>
        {[
          { k: "Budget total engagé", v: fmt(total) },
          { k: "Budget total alloué", v: fmt(totalAlloc) },
          { k: "Jalons à risque", v: `${OPEX_DATA.filter(o => o.status === "watch").length}` },
          { k: "Prochaine revue COMEX", v: "24 juin" },
        ].map((c, i) => (
          <div key={i} style={{ background: "var(--sea)", padding: "1.4rem 1.8rem" }}>
            <div style={{ fontFamily: "monospace", fontSize: "0.48rem", letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--wake)", opacity: 0.7, marginBottom: "0.4rem" }}>{c.k}</div>
            <div style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.4rem", color: "var(--salt)" }}>{c.v}</div>
          </div>
        ))}
      </div>

      {/* OPEX cards */}
      <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
        {OPEX_DATA.map(op => {
          const isWatch = op.status === "watch";
          const statusColor = op.status === "on" ? "var(--green)" : op.status === "watch" ? "var(--amber)" : "var(--wake2)";
          const borderColor = isWatch ? "rgba(212,168,67,0.25)" : "var(--rule2)";

          return (
            <div key={op.id} id={op.id} style={{
              background: "var(--sea)",
              border: `1px solid ${borderColor}`,
              position: "relative",
              overflow: "hidden",
            }}>
              {/* Left accent */}
              <div style={{
                position: "absolute", left: 0, top: 0, bottom: 0, width: "2px",
                background: statusColor,
              }} />

              <div style={{ padding: "2rem 2.2rem 2rem 2.4rem" }}>
                {/* Top */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "1.6rem" }}>
                  <div>
                    <h2 style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.15rem", color: "var(--salt)", lineHeight: 1.3, marginBottom: "0.4rem" }}>
                      {op.name}
                    </h2>
                    <div style={{ fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.1em", color: "var(--foam)", display: "flex", gap: "1.5rem" }}>
                      <span>{op.sprint}</span>
                      <span>Chef : {op.chef}</span>
                      <span>Livraison : {op.delivery}</span>
                    </div>
                  </div>
                  <span style={{
                    fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.12em",
                    textTransform: "uppercase", padding: "0.3rem 0.8rem",
                    border: "1px solid", borderColor: statusColor,
                    color: statusColor, background: `${statusColor}11`, whiteSpace: "nowrap",
                  }}>
                    {STATUS_LABELS[op.status]}
                  </span>
                </div>

                {/* Progress */}
                <div style={{ marginBottom: "1.6rem" }}>
                  <div style={{ height: "2px", background: "var(--rule2)", borderRadius: "1px", overflow: "hidden", marginBottom: "0.4rem" }}>
                    <div style={{
                      height: "100%", width: `${op.progress}%`, borderRadius: "1px",
                      background: isWatch
                        ? "linear-gradient(to right, var(--amber), #E8C06A)"
                        : "linear-gradient(to right, var(--wake), var(--wake2))",
                      transition: "width 1s cubic-bezier(.16,1,.3,1)",
                    }} />
                  </div>
                  <div style={{ fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.1em", color: isWatch ? "var(--amber)" : "var(--wake2)", textAlign: "right" }}>
                    {op.progress}%
                  </div>
                </div>

                {/* KVs */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "1rem", marginBottom: op.risks.length > 0 ? "1.6rem" : "1rem" }}>
                  {[
                    { k: "Budget engagé", v: fmt(op.budgetEngaged) },
                    { k: "Budget alloué", v: fmt(op.budgetTotal) },
                    { k: "Écart prévisionnel", v: op.ecart === 0 ? "—" : `${op.ecart > 0 ? "+" : ""}${op.ecart}%` },
                  ].map((kv, i) => (
                    <div key={i}>
                      <div style={{ fontFamily: "monospace", fontSize: "0.46rem", letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--mist)", marginBottom: "0.2rem" }}>{kv.k}</div>
                      <div style={{
                        fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.1rem",
                        color: kv.k === "Écart prévisionnel" && op.ecart > 5 ? "var(--amber)" : "var(--salt)",
                      }}>{kv.v}</div>
                    </div>
                  ))}
                </div>

                {/* Risks */}
                {op.risks.length > 0 && (
                  <div style={{ marginBottom: "1.6rem", background: "rgba(212,168,67,0.06)", border: "1px solid rgba(212,168,67,0.2)", padding: "0.9rem 1.2rem" }}>
                    <div style={{ fontFamily: "monospace", fontSize: "0.48rem", letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--amber)", marginBottom: "0.5rem" }}>Risques identifiés</div>
                    {op.risks.map((r, i) => (
                      <div key={i} style={{ fontSize: "0.78rem", color: "var(--foam)", paddingLeft: "0.8rem", borderLeft: "1px solid rgba(212,168,67,0.3)", marginBottom: "0.3rem" }}>
                        {r}
                      </div>
                    ))}
                  </div>
                )}

                {/* Actions */}
                <div>
                  <div style={{ fontFamily: "monospace", fontSize: "0.48rem", letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--wake)", marginBottom: "0.6rem" }}>Actions en cours</div>
                  {op.actions.map((a, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: "0.6rem", fontSize: "0.8rem", color: "var(--foam)", marginBottom: "0.35rem" }}>
                      <span style={{ color: "var(--wake)", fontSize: "0.5rem" }}>▸</span>
                      {a}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
