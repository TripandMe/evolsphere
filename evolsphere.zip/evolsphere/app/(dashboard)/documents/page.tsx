export default function DocumentsPage() {
  const docs = [
    { type: "Audio · Interview", title: "Entretien exclusif — Vision & Stratégie", desc: "Écoute complète de l'interview de référence. Format MP3, 2 min.", href: "/FM_ITW_1402.mp3", available: true },
    { type: "Document · Analyse", title: "Analyse stratégique — Développement & Notoriété", desc: "Analyse complète. Format DOCX, 20 Mo.", href: "/MEMOIRE_TCHANQUE_22_02_2024.docx", available: true },
    { type: "À venir", title: "Guide de déploiement EvolSphere", desc: "Disponible à l'activation de votre licence.", href: "#", available: false },
    { type: "À venir", title: "Bon de commande — Traversée Baléares", desc: "Transmis par votre accompagnateur dédié.", href: "#", available: false },
    { type: "À venir", title: "Rapport COMEX Q2 2025", desc: "Publié après la revue du 24 juin.", href: "#", available: false },
    { type: "À venir", title: "Tableau de bord financier — Export PDF", desc: "Disponible via votre espace OPEX.", href: "#", available: false },
  ];

  return (
    <div style={{ padding: "3rem 3rem 5rem" }}>
      <p style={{ fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--wake)", marginBottom: "0.8rem" }}>
        Espace documents
      </p>
      <h1 style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "clamp(1.8rem, 3vw, 2.8rem)", color: "var(--salt)", marginBottom: "3rem" }}>
        Vos ressources
      </h1>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1px", background: "var(--rule2)", border: "1px solid var(--rule2)" }}>
        {docs.map((doc, i) => (
          <div key={i} style={{
            background: "var(--sea)", padding: "2rem 2.2rem",
            display: "flex", flexDirection: "column", gap: "0.8rem",
            opacity: doc.available ? 1 : 0.35,
            position: "relative", overflow: "hidden",
          }}>
            {doc.available && (
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "1px", background: "linear-gradient(to right, transparent, var(--wake), transparent)", opacity: 0.3 }} />
            )}
            <div style={{ fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--wake)" }}>{doc.type}</div>
            <div style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.05rem", color: "var(--salt)", lineHeight: 1.3 }}>{doc.title}</div>
            <div style={{ fontSize: "0.78rem", color: "var(--foam)", lineHeight: 1.7 }}>{doc.desc}</div>
            {doc.available && (
              <a href={doc.href} download style={{
                display: "inline-flex", alignItems: "center", gap: "0.5rem",
                marginTop: "0.4rem", padding: "0.6rem 1.4rem",
                background: "transparent", border: "1px solid var(--rule)",
                color: "var(--wake)", fontFamily: "monospace",
                fontSize: "0.52rem", letterSpacing: "0.14em",
                textTransform: "uppercase", textDecoration: "none",
                alignSelf: "flex-start", transition: "all 0.22s",
              }}>
                ⬇ Télécharger
              </a>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
