import { AGENDA } from "@/data/agenda";

const TAG_COLORS: Record<string, string> = {
  "Membres": "var(--wake2)",
  "Voile": "var(--green)",
  "Sur invitation": "var(--amber)",
  "Ouvert": "var(--foam)",
};

export default function AgendaPage() {
  return (
    <div style={{ padding: "3rem 3rem 5rem" }}>
      <p style={{ fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--wake)", marginBottom: "0.8rem" }}>
        Agenda du cercle
      </p>
      <h1 style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "clamp(1.8rem, 3vw, 2.8rem)", color: "var(--salt)", marginBottom: "3rem" }}>
        Prochains rendez-vous
      </h1>

      <div style={{ display: "flex", flexDirection: "column", gap: "1px", background: "var(--rule2)" }}>
        {AGENDA.map(ev => (
          <div key={ev.id} style={{
            background: "var(--sea)", padding: "1.8rem 2.2rem",
            display: "grid", gridTemplateColumns: "100px 1fr auto",
            alignItems: "center", gap: "2.5rem",
            position: "relative", overflow: "hidden",
            transition: "background 0.2s",
          }}>
            <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: "2px", background: TAG_COLORS[ev.tag] || "var(--wake)", opacity: 0.5 }} />
            <div style={{ paddingLeft: "0.5rem" }}>
              <div style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.8rem", color: "var(--salt)", lineHeight: 1 }}>{ev.day}</div>
              <div style={{ fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--wake)", marginTop: "0.2rem" }}>{ev.month} 2025</div>
            </div>
            <div>
              <div style={{ fontSize: "0.92rem", color: "var(--salt)", marginBottom: "0.4rem", fontWeight: 300 }}>{ev.title}</div>
              <div style={{ fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.08em", color: "var(--foam)" }}>{ev.where}</div>
            </div>
            <span style={{
              fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.1em",
              textTransform: "uppercase", padding: "0.3rem 0.8rem",
              border: "1px solid var(--rule)", color: TAG_COLORS[ev.tag] || "var(--foam)",
              whiteSpace: "nowrap",
            }}>{ev.tag}</span>
          </div>
        ))}
      </div>

      <p style={{ fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.1em", color: "var(--mist)", marginTop: "2rem", textAlign: "center" }}>
        Agenda mis à jour en temps réel · Les invitations sont envoyées par email
      </p>
    </div>
  );
}
