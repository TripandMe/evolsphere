import { auth } from "@/auth";
import { redirect } from "next/navigation";
import Sidebar from "@/components/Sidebar";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session) redirect("/login");

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <Sidebar user={session.user as any} />
      <main style={{
        marginLeft: "220px",
        flex: 1,
        minHeight: "100vh",
        background: "var(--deep)",
      }}>
        {children}
      </main>
    </div>
  );
}
