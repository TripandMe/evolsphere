export interface AgendaEvent {
  id: string;
  day: string;
  month: string;
  title: string;
  where: string;
  tag: "Membres" | "Voile" | "Sur invitation" | "Ouvert";
}

export const AGENDA: AgendaEvent[] = [
  { id: "a1", day: "24", month: "Juin", title: "Revue COMEX — EvolSphere Q2", where: "Visioconférence privée · 18h00 CET", tag: "Membres" },
  { id: "a2", day: "05", month: "Juil.", title: "Dîner Cercle — Palma de Mallorca", where: "Restaurant Es Baluard · 20h30", tag: "Sur invitation" },
  { id: "a3", day: "18", month: "Juil.", title: "Traversée Baléares — Palma ⟶ Formentera", where: "Marina Portitxol · 08h00 — 5 jours", tag: "Voile" },
  { id: "a4", day: "18", month: "Sept.", title: "Atelier Méthodo — Arbitrage portefeuille projets", where: "Lieu à confirmer · Demi-journée", tag: "Membres" },
  { id: "a5", day: "10", month: "Oct.", title: "Assemblée annuelle EvolSphere", where: "Cannes · Hôtel Martinez", tag: "Membres" },
];
