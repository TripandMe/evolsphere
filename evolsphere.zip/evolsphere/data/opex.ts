export type OpexStatus = "on" | "watch" | "plan" | "done";

export interface Opex {
  id: string;
  name: string;
  status: OpexStatus;
  progress: number;
  sprint: string;
  chef: string;
  budgetEngaged: number;
  budgetTotal: number;
  ecart: number; // percent
  delivery: string;
  actions: string[];
  risks: string[];
}

export const OPEX_DATA: Opex[] = [
  {
    id: "op1",
    name: "Refonte système d'information — Pôle Finance",
    status: "on",
    progress: 72,
    sprint: "Sprint 8 / 11",
    chef: "M. Arnaud",
    budgetEngaged: 148000,
    budgetTotal: 205000,
    ecart: 3,
    delivery: "15 sept. 2025",
    actions: ["Valider recette sprint 8", "Planifier démo COMEX", "Mise à jour RACI"],
    risks: [],
  },
  {
    id: "op2",
    name: "Déploiement ERP — Sites régionaux",
    status: "watch",
    progress: 41,
    sprint: "Phase 2 / 4",
    chef: "S. Mérel",
    budgetEngaged: 87000,
    budgetTotal: 210000,
    ecart: 12,
    delivery: "3 nov. 2025",
    actions: ["Arbitrage dépassement budget", "Renforcer équipe phase 3"],
    risks: ["Dépassement budget +12%", "Retard livraison site Lyon"],
  },
  {
    id: "op3",
    name: "Optimisation chaîne logistique — Sud-Est",
    status: "on",
    progress: 88,
    sprint: "Phase finale",
    chef: "P. Varela",
    budgetEngaged: 212000,
    budgetTotal: 220000,
    ecart: -2,
    delivery: "30 juin 2025",
    actions: ["Clôture documentaire", "Bilan ROI"],
    risks: [],
  },
  {
    id: "op4",
    name: "Certification ISO 27001 — DSI",
    status: "plan",
    progress: 18,
    sprint: "Cadrage",
    chef: "À définir",
    budgetEngaged: 10000,
    budgetTotal: 55000,
    ecart: 0,
    delivery: "Fév. 2026",
    actions: ["Nommer chef de projet", "Lancer appel d'offres audit"],
    risks: [],
  },
];

export const STATUS_LABELS: Record<OpexStatus, string> = {
  on: "En cours",
  watch: "Vigilance",
  plan: "Planifié",
  done: "Terminé",
};
