# EvolSphere — Cercle Privé

Espace membres Next.js 16 · App Router · NextAuth v5

## Lancer en local

```bash
npm install
cp .env.example .env.local
# Éditez NEXTAUTH_SECRET dans .env.local
npm run dev
```

Accès demo : `membre1@evolsphere.io` / `evol2025`

## Déployer sur Vercel

1. Pusher ce dossier sur un repo GitHub
2. Importer dans [vercel.com](https://vercel.com)
3. Ajouter les variables d'environnement :
   - `NEXTAUTH_URL` = `https://votre-app.vercel.app`
   - `NEXTAUTH_SECRET` = générer avec `openssl rand -base64 32`
4. Deploy ✓

## Structure

```
app/
  (auth)/login/        → Page de connexion
  (dashboard)/
    page.tsx           → Vue d'ensemble
    opex/              → Board OPEX complet
    traversee/         → Traversée Baléares
    agenda/            → Agenda du cercle
    documents/         → Téléchargements
components/
  Sidebar.tsx          → Navigation latérale
data/
  opex.ts              → Données OPEX (à brancher sur DB)
  agenda.ts            → Événements
lib/
  users.ts             → Membres (remplacer par DB en prod)
auth.ts                → Config NextAuth
middleware.ts          → Protection routes
```

## Ajouter de vrais membres

Remplacez `lib/users.ts` par une requête DB (Prisma, Supabase, etc.) ou ajoutez un provider OAuth (Google, GitHub) dans `auth.ts`.
