// Demo member accounts — replace with DB in production
export const MEMBERS = [
  {
    id: "1",
    email: "membre1@evolsphere.io",
    password: "evol2025",
    name: "Alexandre Moreau",
    role: "Directeur Général",
    avatar: "AM",
  },
  {
    id: "2",
    email: "membre2@evolsphere.io",
    password: "evol2025",
    name: "Sophie Durand",
    role: "DRH",
    avatar: "SD",
  },
  {
    id: "3",
    email: "admin@evolsphere.io",
    password: "admin2025",
    name: "Admin EvolSphere",
    role: "Administrateur",
    avatar: "ES",
  },
];

export function findUser(email: string, password: string) {
  return MEMBERS.find(
    (u) => u.email === email && u.password === password
  ) ?? null;
}
