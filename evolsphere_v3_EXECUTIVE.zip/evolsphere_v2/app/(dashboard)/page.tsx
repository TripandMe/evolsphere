import { auth } from "@/auth";
export default async function DashboardPage(){
 const session=await auth();
 return (<div style={{padding:"3rem"}}>
 <h1 style={{fontSize:"3rem"}}>EVOLSPHERE Executive</h1>
 <p>Bonjour {session?.user?.name?.split(" ")[0]}</p>
 <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:"1rem"}}>
 {["Risk Radar","Executive Brief","Participations","Agenda stratégique"].map(t=><div key={t} style={{border:"1px solid #ddd",padding:"1rem",borderRadius:"8px"}}><h3>{t}</h3><p>Module prêt à enrichir.</p></div>)}
 </div>
 </div>)
}