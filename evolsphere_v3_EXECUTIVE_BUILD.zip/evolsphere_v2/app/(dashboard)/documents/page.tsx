export default function DocumentsPage() {
  const ressources = [
    {
      categorie: "Entretien exclusif · Audio",
      titre: "Vision stratégique — Interview de référence",
      description: "Écoute intégrale de l'entretien de référence. Format MP3, 2 minutes.",
      lien: "/FM_ITW_1402.mp3",
      disponible: true,
    },
    {
      categorie: "Analyse · Document de travail",
      titre: "Analyse stratégique — Développement & Notoriété",
      description: "Analyse complète disponible en téléchargement. Format Word, 20 Mo.",
      lien: "/MEMOIRE_TCHANQUE_22_02_2024.docx",
      disponible: true,
    },
    {
      categorie: "À venir",
      titre: "Guide de déploiement EvolSphere",
      description: "Disponible à l'activation de votre licence.",
      lien: "#",
      disponible: false,
    },
    {
      categorie: "À venir",
      titre: "Convention de participation — Traversée des Baléares",
      description: "Transmis par votre accompagnateur dédié.",
      lien: "#",
      disponible: false,
    },
    {
      categorie: "À venir",
      titre: "Compte rendu de la revue de direction — Juin 2025",
      description: "Publié après la revue du 24 juin.",
      lien: "#",
      disponible: false,
    },
    {
      categorie: "À venir",
      titre: "Tableau de bord financier — Export PDF",
      description: "Disponible depuis votre espace programmes.",
      lien: "#",
      disponible: false,
    },
  ];

  return (
    <div style={{ padding: "3rem 3rem 5rem" }}>
      <p style={{ fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--wake)", marginBottom: "0.8rem" }}>
        Espace documentaire
      </p>
      <h1 style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "clamp(1.8rem, 3vw, 2.8rem)", color: "var(--salt)", marginBottom: "3rem" }}>
        Vos ressources
      </h1>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1px", background: "var(--rule2)", border: "1px solid var(--rule2)" }}>
        {ressources.map((doc, i) => (
          <div key={i} style={{
            background: "var(--sea)", padding: "2rem 2.2rem",
            display: "flex", flexDirection: "column", gap: "0.8rem",
            opacity: doc.disponible ? 1 : 0.35,
            position: "relative", overflow: "hidden",
          }}>
            {doc.disponible && (
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "1px", background: "linear-gradient(to right, transparent, var(--wake), transparent)", opacity: 0.3 }} />
            )}
            <div style={{ fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--wake)" }}>{doc.categorie}</div>
            <div style={{ fontFamily: "Georgia, serif", fontWeight: 200, fontSize: "1.05rem", color: "var(--salt)", lineHeight: 1.3 }}>{doc.titre}</div>
            <div style={{ fontSize: "0.78rem", color: "var(--foam)", lineHeight: 1.7 }}>{doc.description}</div>
            {doc.disponible && (
              <a href={doc.lien} download style={{
                display: "inline-flex", alignItems: "center", gap: "0.5rem",
                marginTop: "0.4rem", padding: "0.6rem 1.4rem",
                background: "transparent", border: "1px solid var(--rule)",
                color: "var(--wake)", fontFamily: "monospace",
                fontSize: "0.52rem", letterSpacing: "0.14em",
                textTransform: "uppercase", textDecoration: "none",
                alignSelf: "flex-start", transition: "all 0.22s",
              }}>
                ⬇ Télécharger
              </a>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
