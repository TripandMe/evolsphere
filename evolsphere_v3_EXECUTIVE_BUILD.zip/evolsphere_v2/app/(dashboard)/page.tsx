export default function DashboardPage() {
return (
<div style={{padding:"3rem"}}>
<h1>EvolSphere Executive</h1>
<p>Centre de pilotage stratégique.</p>
<ul>
<li>Risk Radar</li>
<li>Executive Brief</li>
<li>Participations</li>
<li>Agenda Stratégique</li>
</ul>
</div>
);
}