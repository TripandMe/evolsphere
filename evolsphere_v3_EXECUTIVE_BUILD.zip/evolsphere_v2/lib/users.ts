export const MEMBERS = [
  {
    id: "rdb",
    email: "raphael@de-bruijn.com",
    password: "RdB_EvolSphere2026!",
    name: "Raphaël de Bruijn",
    role: "Fondateur · Directeur de Programme",
    avatar: "RB",
  },
  {
    id: "client1",
    email: "client1@evolsphere.com",
    password: "client1_2026",
    name: "Client 1",
    role: "Directeur de Projet",
    avatar: "C1",
  },
  {
    id: "client2",
    email: "client2@evolsphere.com",
    password: "client2_2026",
    name: "Client 2",
    role: "Directeur des Systèmes d'Information",
    avatar: "C2",
  },
  {
    id: "client3",
    email: "client3@evolsphere.com",
    password: "client3_2026",
    name: "Client 3",
    role: "Directeur des Opérations",
    avatar: "C3",
  },
];

export function findUser(email: string, password: string) {
  return MEMBERS.find((u) => u.email === email && u.password === password) ?? null;
}
