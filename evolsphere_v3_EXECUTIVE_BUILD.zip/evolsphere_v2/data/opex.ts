export type OpexStatus = "on" | "watch" | "plan" | "done";

export interface Opex {
  id: string;
  name: string;
  status: OpexStatus;
  progress: number;
  phase: string;
  directeur: string;
  budgetEngaged: number;
  budgetTotal: number;
  ecart: number;
  livraison: string;
  actions: string[];
  risques: string[];
}

export const OPEX_DATA: Opex[] = [
  {
    id: "op1",
    name: "Refonte du Système d'Information — Pôle Finance",
    status: "on",
    progress: 72,
    phase: "Phase de réalisation — Itération 8 / 11",
    directeur: "M. Arnaud",
    budgetEngaged: 148000,
    budgetTotal: 205000,
    ecart: 3,
    livraison: "15 septembre 2025",
    actions: [
      "Valider la recette de la huitième itération",
      "Planifier la présentation au Comité Exécutif",
      "Mettre à jour la matrice de responsabilités",
    ],
    risques: [],
  },
  {
    id: "op2",
    name: "Déploiement Progiciel de Gestion — Sites Régionaux",
    status: "watch",
    progress: 41,
    phase: "Deuxième phase sur quatre — Point de vigilance",
    directeur: "S. Mérel",
    budgetEngaged: 87000,
    budgetTotal: 210000,
    ecart: 12,
    livraison: "3 novembre 2025",
    actions: [
      "Arbitrage dépassement d'enveloppe budgétaire",
      "Renforcement des ressources pour la troisième phase",
    ],
    risques: [
      "Dépassement budgétaire prévisionnel : +12 %",
      "Retard de livraison — site de Lyon",
    ],
  },
  {
    id: "op3",
    name: "Optimisation de la Chaîne Logistique — Région Sud-Est",
    status: "on",
    progress: 88,
    phase: "Phase de clôture",
    directeur: "P. Varela",
    budgetEngaged: 212000,
    budgetTotal: 220000,
    ecart: -2,
    livraison: "30 juin 2025",
    actions: [
      "Finalisation de la documentation de clôture",
      "Bilan du retour sur investissement",
    ],
    risques: [],
  },
  {
    id: "op4",
    name: "Certification ISO 27001 — Direction des Systèmes d'Information",
    status: "plan",
    progress: 18,
    phase: "Cadrage et initialisation",
    directeur: "À désigner",
    budgetEngaged: 10000,
    budgetTotal: 55000,
    ecart: 0,
    livraison: "Février 2026",
    actions: [
      "Désignation du directeur de programme",
      "Lancement de l'appel d'offres — audit de certification",
    ],
    risques: [],
  },
];

export const STATUS_LABELS: Record<OpexStatus, string> = {
  on: "En cours",
  watch: "Vigilance",
  plan: "Planifié",
  done: "Terminé",
};
