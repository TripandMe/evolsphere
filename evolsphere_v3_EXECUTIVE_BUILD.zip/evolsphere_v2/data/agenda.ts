export interface AgendaEvent {
  id: string;
  day: string;
  month: string;
  title: string;
  where: string;
  tag: "Membres" | "Voile" | "Sur invitation" | "Ouvert";
}

export const AGENDA: AgendaEvent[] = [
  {
    id: "a1",
    day: "24",
    month: "Juin",
    title: "Revue du Cercle — Bilan semestriel",
    where: "Visioconférence privée · 18 h 00 CET",
    tag: "Membres",
  },
  {
    id: "a2",
    day: "05",
    month: "Juil.",
    title: "Dîner du Cercle — Palma de Majorque",
    where: "Restaurant Es Baluard · 20 h 30",
    tag: "Sur invitation",
  },
  {
    id: "a3",
    day: "18",
    month: "Juil.",
    title: "Traversée des Baléares — Palma ⟶ Formentera",
    where: "Marina Portitxol · 08 h 00 — cinq jours",
    tag: "Voile",
  },
  {
    id: "a4",
    day: "18",
    month: "Sept.",
    title: "Atelier — Arbitrage de portefeuille de programmes",
    where: "Lieu à confirmer · Demi-journée",
    tag: "Membres",
  },
  {
    id: "a5",
    day: "10",
    month: "Oct.",
    title: "Assemblée annuelle EvolSphere",
    where: "Cannes · Hôtel Martinez",
    tag: "Membres",
  },
];
