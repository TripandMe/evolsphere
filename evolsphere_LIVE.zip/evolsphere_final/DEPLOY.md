# Déploiement EvolSphere sur Vercel

## Étape 1 — Générer le secret NextAuth
```bash
openssl rand -base64 32
```
Copiez la valeur générée → vous en aurez besoin à l'étape 3.

## Étape 2 — Pousser sur GitHub
1. Allez sur github.com → New repository → "evolsphere"
2. Dans votre terminal (ou GitHub Desktop) :
```bash
cd evolsphere
git init
git add .
git commit -m "EvolSphere v1.0"
git remote add origin https://github.com/VOTRE_USER/evolsphere.git
git push -u origin main
```

## Étape 3 — Déployer sur Vercel
1. vercel.com → New Project → Import depuis GitHub → "evolsphere"
2. Framework : Next.js (auto-détecté)
3. Environment Variables → Ajouter :
   - `NEXTAUTH_URL` = `https://evolsphere.com`
   - `NEXTAUTH_SECRET` = (la valeur de l'étape 1)
4. Deploy → votre app est live sur xxxxx.vercel.app

## Étape 4 — Connecter evolsphere.com
1. Vercel → Settings → Domains → Add → `evolsphere.com`
2. Vercel vous donne 2 records DNS
3. Porkbun → DNS :
   - Record A : `@` → `76.76.21.21`
   - Record CNAME : `www` → `cname.vercel-dns.com`
4. Attendre 5-10 min → votre site est live sur evolsphere.com

## Étape 5 — Personnaliser les clients
Éditez `lib/users.ts` → remplacez Client 1/2/3 par vos vrais clients.
Changez les mots de passe par défaut !

## Connexion
URL : https://evolsphere.com/login
Admin : raphael@de-bruijn.com / RdB_EvolSphere2026!
