// EvolSphere — Membres & Clients
// Ajoutez vos clients ici. En production : migrer vers une base de données.
export const MEMBERS = [
  // ── ADMIN ──────────────────────────────────
  {
    id: "rdb",
    email: "raphael@de-bruijn.com",
    password: "RdB_EvolSphere2026!",
    name: "Raphaël de Bruijn",
    role: "Fondateur · PMO Senior",
    avatar: "RB",
  },

  // ── CLIENT 1 ───────────────────────────────
  {
    id: "client1",
    email: "client1@evolsphere.com",
    password: "client1_2026",
    name: "Client 1",
    role: "Directeur de Projet",
    avatar: "C1",
  },

  // ── CLIENT 2 ───────────────────────────────
  {
    id: "client2",
    email: "client2@evolsphere.com",
    password: "client2_2026",
    name: "Client 2",
    role: "DSI",
    avatar: "C2",
  },

  // ── CLIENT 3 ───────────────────────────────
  {
    id: "client3",
    email: "client3@evolsphere.com",
    password: "client3_2026",
    name: "Client 3",
    role: "COO",
    avatar: "C3",
  },
];

export function findUser(email: string, password: string) {
  return MEMBERS.find(
    (u) => u.email === email && u.password === password
  ) ?? null;
}
