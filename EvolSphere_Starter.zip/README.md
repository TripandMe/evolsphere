# EvolSphere Starter

Starter project structure.
